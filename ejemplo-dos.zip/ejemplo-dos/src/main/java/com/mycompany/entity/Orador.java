package com.mycompany.entity;

/**
 *
 * @author Nicolas
 */
public class Orador extends Persona {
    
    //Definimos variables
    private String tema;
    
    //Constructor
    
    public Orador(){}
    
    public Orador(long i, String n, String a , String t) {
        super(i, n, a);
        this.tema = t;
    }
    


    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }
    
    //Métodos
    public void exponerCharla() {
        System.out.println("Hola soy Bill Gates y voy a hablar del nuevo orden mundial.");
    }

    public String saludar() {
        String uno = "Hola";
        int numero = 2;
        
        return String.valueOf(numero);
    }
    
    public void inscribirseEnLaConferencia() {
        System.out.println("Datos Ingresados y validados.");
    }

    @Override
    public String toString() {
        return super.toString() + "Orador{" + "tema=" + tema + '}';
    }
    
    

}
