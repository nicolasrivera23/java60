package com.mycompany.test;

import com.mycompany.entity.Orador;

/**
 *
 * @author Nicolas
 */
public class OradorTest {
    
    public static void main(String[] args) {   

        Orador oraUno = new Orador();
        oraUno.setId(1);
        oraUno.setNombre("Steve");
        oraUno.setApellido("Jobs");
        oraUno.setTema("Apple y el medio ambiente");

        System.out.println(oraUno);
        
    //instancia de la clase Orador
    //Orador oradorUno = new Orador(1L, "Juancito", "Saralegui", "De que signo es Justin");
    //System.out.println(oradorUno);
    
    //Orador oradorDos = new Orador();
    //oradorDos.setId(2);
    //oradorDos.setNombre("Ada");
    //oradorDos.setApellido("Byron");
    //oradorDos.setTema("El origen del universo");
    //System.out.println("getId orador: " + oradorDos.getId());
    
    //System.out.println(oradorDos);
    

    }
    
    
    
    
    
    
    
    
}
